const wizards = [
    {name: "a", magicWand: "c", house: "k"},
    {name: "h", magicWand: "f", house: "k"},
    {name: "d", magicWand: "e", house: "j"},
]

export default wizards